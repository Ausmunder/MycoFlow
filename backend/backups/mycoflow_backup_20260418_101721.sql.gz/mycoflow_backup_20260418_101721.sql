--
-- PostgreSQL database dump
--

\restrict sgFtlgmNRcYZjM6lJCmCIwLY7iGWTb0K8ijpzsMdkAivcdWx8UjvtqsAVosf4yh

-- Dumped from database version 17.7 (Debian 17.7-0+deb13u1)
-- Dumped by pg_dump version 17.7 (Debian 17.7-0+deb13u1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: mycoflow
--

-- *not* creating schema, since initdb creates it


ALTER SCHEMA public OWNER TO mycoflow;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: batch_info; Type: TABLE; Schema: public; Owner: mycoflow
--

CREATE TABLE public.batch_info (
    id integer NOT NULL,
    spawn_batch character varying NOT NULL,
    strain_name character varying NOT NULL,
    in_fridge boolean,
    fridge_start_date timestamp without time zone,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone
);


ALTER TABLE public.batch_info OWNER TO mycoflow;

--
-- Name: batch_info_id_seq; Type: SEQUENCE; Schema: public; Owner: mycoflow
--

CREATE SEQUENCE public.batch_info_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.batch_info_id_seq OWNER TO mycoflow;

--
-- Name: batch_info_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mycoflow
--

ALTER SEQUENCE public.batch_info_id_seq OWNED BY public.batch_info.id;


--
-- Name: batch_units; Type: TABLE; Schema: public; Owner: mycoflow
--

CREATE TABLE public.batch_units (
    id integer NOT NULL,
    batch_info_id integer NOT NULL,
    type character varying,
    substrat character varying,
    kg double precision NOT NULL,
    dato_inok timestamp without time zone,
    status character varying,
    used_in_bag character varying,
    contaminated boolean,
    contamination_date timestamp without time zone,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone,
    contamination_phase character varying(20),
    contamination_notes text
);


ALTER TABLE public.batch_units OWNER TO mycoflow;

--
-- Name: COLUMN batch_units.contamination_phase; Type: COMMENT; Schema: public; Owner: mycoflow
--

COMMENT ON COLUMN public.batch_units.contamination_phase IS 'Phase when contamination occurred: spawn, colonization, fruiting';


--
-- Name: COLUMN batch_units.contamination_notes; Type: COMMENT; Schema: public; Owner: mycoflow
--

COMMENT ON COLUMN public.batch_units.contamination_notes IS 'Optional notes about contamination';


--
-- Name: batch_units_id_seq; Type: SEQUENCE; Schema: public; Owner: mycoflow
--

CREATE SEQUENCE public.batch_units_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.batch_units_id_seq OWNER TO mycoflow;

--
-- Name: batch_units_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mycoflow
--

ALTER SEQUENCE public.batch_units_id_seq OWNED BY public.batch_units.id;


--
-- Name: batches; Type: TABLE; Schema: public; Owner: mycoflow
--

CREATE TABLE public.batches (
    id integer NOT NULL,
    batch_type character varying NOT NULL,
    strain_name character varying NOT NULL,
    lc_batch character varying,
    lc_vol character varying,
    lc_dato_inok timestamp without time zone,
    spawn_batch character varying,
    spawn_type character varying,
    spawn_dato_inok timestamp without time zone,
    spawn_kg double precision,
    spawn_dager_ink integer,
    bag_batch character varying,
    bag_forventet_kolon timestamp without time zone,
    bag_substrat_type character varying,
    bag_kg_substrat double precision,
    bag_dato_inok timestamp without time zone,
    bag_dager_ink integer,
    bag_status character varying,
    bag_frukting_start timestamp without time zone,
    bag_temp_kammer double precision,
    bag_lf_kammer double precision,
    bag_host1_start timestamp without time zone,
    bag_host1_slutt timestamp without time zone,
    bag_host1_total_kg double precision,
    bag_host1_dager integer,
    bag_host2_start timestamp without time zone,
    bag_host2_slutt timestamp without time zone,
    bag_host2_total_kg double precision,
    bag_host2_dager integer,
    bag_syklus_lengde integer,
    bag_be_percent double precision,
    archived boolean,
    notes text,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone,
    qr_code character varying(100),
    qr_data text,
    label_printed boolean DEFAULT false,
    label_printed_at timestamp without time zone,
    label_print_count integer DEFAULT 0,
    workflow_status character varying(50) DEFAULT 'Spawn'::character varying,
    in_fridge boolean DEFAULT false,
    fridge_date timestamp without time zone,
    spawn_forventet_ferdig timestamp without time zone,
    lc_id integer,
    bag_temp double precision,
    spawn_expected_ready_date timestamp without time zone,
    spawn_actual_ready_date timestamp without time zone,
    colonization_expected_date timestamp without time zone,
    colonization_actual_date timestamp without time zone,
    colonization_temp_c double precision,
    fruiting_start_date timestamp without time zone,
    fruiting_temp_c double precision,
    flush1_expected_date timestamp without time zone,
    flush1_actual_start_date timestamp without time zone,
    flush1_harvest_date timestamp without time zone,
    flush1_expected_kg double precision,
    flush1_actual_kg double precision,
    flush2_expected_date timestamp without time zone,
    flush2_actual_start_date timestamp without time zone,
    flush2_harvest_date timestamp without time zone,
    flush2_expected_kg double precision,
    flush2_actual_kg double precision,
    flush3_expected_date timestamp without time zone,
    flush3_actual_start_date timestamp without time zone,
    flush3_harvest_date timestamp without time zone,
    flush3_harvest_kg double precision,
    contaminated_units integer DEFAULT 0,
    bag_antall_bager integer,
    spawn_contaminated_units integer,
    bag_contaminated_units integer,
    inkubering_contaminated_units integer,
    frukt1_contaminated_units integer,
    frukt2_contaminated_units integer,
    spawn_contamination_type character varying,
    inkubering_contamination_type character varying,
    frukt1_contamination_type character varying,
    frukt2_contamination_type character varying,
    spawn_abortert boolean DEFAULT false,
    inkubering_abortert boolean DEFAULT false,
    frukt1_abortert boolean DEFAULT false,
    frukt2_abortert boolean DEFAULT false
);


ALTER TABLE public.batches OWNER TO mycoflow;

--
-- Name: batches_id_seq; Type: SEQUENCE; Schema: public; Owner: mycoflow
--

CREATE SEQUENCE public.batches_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.batches_id_seq OWNER TO mycoflow;

--
-- Name: batches_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mycoflow
--

ALTER SEQUENCE public.batches_id_seq OWNED BY public.batches.id;


--
-- Name: contamination_log; Type: TABLE; Schema: public; Owner: mycoflow
--

CREATE TABLE public.contamination_log (
    id integer NOT NULL,
    lc_code character varying(50) NOT NULL,
    strain_name character varying(50) NOT NULL,
    batch_id integer,
    batch_unit_id integer,
    contamination_phase character varying(20) NOT NULL,
    contamination_date timestamp without time zone DEFAULT now(),
    batch_type character varying(10),
    batch_identifier character varying(100),
    substrat_type character varying(50),
    notes text,
    created_at timestamp without time zone DEFAULT now(),
    CONSTRAINT contamination_log_contamination_phase_check CHECK (((contamination_phase)::text = ANY (ARRAY[('spawn'::character varying)::text, ('colonization'::character varying)::text, ('fruiting'::character varying)::text])))
);


ALTER TABLE public.contamination_log OWNER TO mycoflow;

--
-- Name: TABLE contamination_log; Type: COMMENT; Schema: public; Owner: mycoflow
--

COMMENT ON TABLE public.contamination_log IS 'Historical log of all contamination events across all phases';


--
-- Name: COLUMN contamination_log.contamination_phase; Type: COMMENT; Schema: public; Owner: mycoflow
--

COMMENT ON COLUMN public.contamination_log.contamination_phase IS 'Phase: spawn, colonization, or fruiting';


--
-- Name: lc_cultures; Type: TABLE; Schema: public; Owner: mycoflow
--

CREATE TABLE public.lc_cultures (
    id integer NOT NULL,
    lc_code character varying(50) NOT NULL,
    strain_name character varying(50) NOT NULL,
    source character varying(100),
    date_created date,
    notes text,
    active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.lc_cultures OWNER TO mycoflow;

--
-- Name: contamination_archive; Type: VIEW; Schema: public; Owner: mycoflow
--

CREATE VIEW public.contamination_archive AS
 SELECT cl.id,
    cl.contamination_date,
    cl.lc_code,
    lc.source AS lc_source,
    cl.strain_name,
    cl.contamination_phase,
    cl.batch_type,
    cl.batch_identifier,
    cl.substrat_type,
    bu.type AS unit_type,
    bu.kg AS unit_kg,
    bu.dato_inok AS unit_inoculation_date,
    cl.notes,
        CASE
            WHEN (bu.dato_inok IS NOT NULL) THEN EXTRACT(day FROM (cl.contamination_date - bu.dato_inok))
            ELSE NULL::numeric
        END AS days_since_inoculation
   FROM ((public.contamination_log cl
     LEFT JOIN public.lc_cultures lc ON (((cl.lc_code)::text = (lc.lc_code)::text)))
     LEFT JOIN public.batch_units bu ON ((cl.batch_unit_id = bu.id)))
  ORDER BY cl.contamination_date DESC;


ALTER VIEW public.contamination_archive OWNER TO mycoflow;

--
-- Name: VIEW contamination_archive; Type: COMMENT; Schema: public; Owner: mycoflow
--

COMMENT ON VIEW public.contamination_archive IS 'Full contamination archive with all relevant details for reporting';


--
-- Name: contamination_log_id_seq; Type: SEQUENCE; Schema: public; Owner: mycoflow
--

CREATE SEQUENCE public.contamination_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.contamination_log_id_seq OWNER TO mycoflow;

--
-- Name: contamination_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mycoflow
--

ALTER SEQUENCE public.contamination_log_id_seq OWNED BY public.contamination_log.id;


--
-- Name: contamination_statistics; Type: VIEW; Schema: public; Owner: mycoflow
--

CREATE VIEW public.contamination_statistics AS
 SELECT lc_code,
    strain_name,
    contamination_phase,
    count(*) AS total_contaminated,
    count(DISTINCT batch_id) AS affected_batches,
    count(DISTINCT date(contamination_date)) AS affected_days,
    min(contamination_date) AS first_occurrence,
    max(contamination_date) AS last_occurrence,
    round((((count(*))::numeric / (NULLIF(( SELECT count(*) AS count
           FROM (public.batch_units bu
             JOIN public.batch_info bi ON ((bu.batch_info_id = bi.id)))
          WHERE ((bi.strain_name)::text = (contamination_log.strain_name)::text)), 0))::numeric) * (100)::numeric), 2) AS contamination_rate_percent
   FROM public.contamination_log
  GROUP BY lc_code, strain_name, contamination_phase
  ORDER BY lc_code, contamination_phase;


ALTER VIEW public.contamination_statistics OWNER TO mycoflow;

--
-- Name: VIEW contamination_statistics; Type: COMMENT; Schema: public; Owner: mycoflow
--

COMMENT ON VIEW public.contamination_statistics IS 'Aggregated contamination statistics per LC per phase';


--
-- Name: lc_cultures_id_seq; Type: SEQUENCE; Schema: public; Owner: mycoflow
--

CREATE SEQUENCE public.lc_cultures_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.lc_cultures_id_seq OWNER TO mycoflow;

--
-- Name: lc_cultures_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mycoflow
--

ALTER SEQUENCE public.lc_cultures_id_seq OWNED BY public.lc_cultures.id;


--
-- Name: strain_statistics; Type: TABLE; Schema: public; Owner: mycoflow
--

CREATE TABLE public.strain_statistics (
    id integer NOT NULL,
    strain_name character varying(50) NOT NULL,
    lc_code character varying(50),
    avg_colonization_days integer,
    min_colonization_days integer,
    max_colonization_days integer,
    avg_yield_kg numeric(10,2),
    total_batches integer DEFAULT 0,
    successful_batches integer DEFAULT 0,
    contamination_rate numeric(5,2),
    avg_be_percent numeric(5,2),
    updated_at timestamp without time zone DEFAULT now(),
    avg_spawn_days double precision,
    avg_fruiting_days double precision,
    avg_flush1_days double precision,
    avg_flush1_kg double precision,
    avg_flush2_kg double precision,
    avg_flush2_yield_kg double precision,
    avg_flushes_per_batch double precision
);


ALTER TABLE public.strain_statistics OWNER TO mycoflow;

--
-- Name: strain_statistics_id_seq; Type: SEQUENCE; Schema: public; Owner: mycoflow
--

CREATE SEQUENCE public.strain_statistics_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.strain_statistics_id_seq OWNER TO mycoflow;

--
-- Name: strain_statistics_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mycoflow
--

ALTER SEQUENCE public.strain_statistics_id_seq OWNED BY public.strain_statistics.id;


--
-- Name: substrate_mixes; Type: TABLE; Schema: public; Owner: mycoflow
--

CREATE TABLE public.substrate_mixes (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    description text,
    moisture_content numeric(4,3),
    is_active boolean,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone,
    recipe_ingredients text,
    grams_per_bag integer
);


ALTER TABLE public.substrate_mixes OWNER TO mycoflow;

--
-- Name: substrate_mixes_id_seq; Type: SEQUENCE; Schema: public; Owner: mycoflow
--

CREATE SEQUENCE public.substrate_mixes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.substrate_mixes_id_seq OWNER TO mycoflow;

--
-- Name: substrate_mixes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mycoflow
--

ALTER SEQUENCE public.substrate_mixes_id_seq OWNED BY public.substrate_mixes.id;


--
-- Name: templates; Type: TABLE; Schema: public; Owner: mycoflow
--

CREATE TABLE public.templates (
    id integer NOT NULL,
    name character varying NOT NULL,
    strain_name character varying NOT NULL,
    units_config text NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone
);


ALTER TABLE public.templates OWNER TO mycoflow;

--
-- Name: templates_id_seq; Type: SEQUENCE; Schema: public; Owner: mycoflow
--

CREATE SEQUENCE public.templates_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.templates_id_seq OWNER TO mycoflow;

--
-- Name: templates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mycoflow
--

ALTER SEQUENCE public.templates_id_seq OWNED BY public.templates.id;


--
-- Name: batch_info id; Type: DEFAULT; Schema: public; Owner: mycoflow
--

ALTER TABLE ONLY public.batch_info ALTER COLUMN id SET DEFAULT nextval('public.batch_info_id_seq'::regclass);


--
-- Name: batch_units id; Type: DEFAULT; Schema: public; Owner: mycoflow
--

ALTER TABLE ONLY public.batch_units ALTER COLUMN id SET DEFAULT nextval('public.batch_units_id_seq'::regclass);


--
-- Name: batches id; Type: DEFAULT; Schema: public; Owner: mycoflow
--

ALTER TABLE ONLY public.batches ALTER COLUMN id SET DEFAULT nextval('public.batches_id_seq'::regclass);


--
-- Name: contamination_log id; Type: DEFAULT; Schema: public; Owner: mycoflow
--

ALTER TABLE ONLY public.contamination_log ALTER COLUMN id SET DEFAULT nextval('public.contamination_log_id_seq'::regclass);


--
-- Name: lc_cultures id; Type: DEFAULT; Schema: public; Owner: mycoflow
--

ALTER TABLE ONLY public.lc_cultures ALTER COLUMN id SET DEFAULT nextval('public.lc_cultures_id_seq'::regclass);


--
-- Name: strain_statistics id; Type: DEFAULT; Schema: public; Owner: mycoflow
--

ALTER TABLE ONLY public.strain_statistics ALTER COLUMN id SET DEFAULT nextval('public.strain_statistics_id_seq'::regclass);


--
-- Name: substrate_mixes id; Type: DEFAULT; Schema: public; Owner: mycoflow
--

ALTER TABLE ONLY public.substrate_mixes ALTER COLUMN id SET DEFAULT nextval('public.substrate_mixes_id_seq'::regclass);


--
-- Name: templates id; Type: DEFAULT; Schema: public; Owner: mycoflow
--

ALTER TABLE ONLY public.templates ALTER COLUMN id SET DEFAULT nextval('public.templates_id_seq'::regclass);


--
-- Data for Name: batch_info; Type: TABLE DATA; Schema: public; Owner: mycoflow
--

COPY public.batch_info (id, spawn_batch, strain_name, in_fridge, fridge_start_date, created_at, updated_at) FROM stdin;
1	TEST-01	oyster	t	2025-11-27 16:26:50.015302	2025-11-27 17:26:23.317553+01	2025-11-27 17:26:50.014052+01
2	adf	oyster	f	\N	2025-11-27 21:28:51.164361+01	\N
3	asdf	oyster	f	\N	2025-11-27 21:32:42.37961+01	\N
4	TEST-23	oyster	f	\N	2025-12-03 17:54:28.478944+01	\N
5	asdfasdf	oyster	f	\N	2025-12-03 18:04:53.657545+01	\N
6	SPF-01	oyster	f	\N	2025-12-03 19:46:41.47925+01	\N
7	TEST-93	oyster	f	\N	2025-12-03 20:42:20.835978+01	\N
8	TEST43	oyster	f	\N	2025-12-03 21:10:22.263361+01	\N
9	TEST-101	lions_mane	f	\N	2025-12-04 14:26:28.913295+01	\N
10	5	oyster	f	\N	2025-12-04 15:27:58.062247+01	\N
11	9	oyster	f	\N	2025-12-04 15:29:03.787553+01	\N
12	TEST-3	oyster	f	\N	2025-12-05 09:20:18.434219+01	\N
13	TEST-35	oyster	f	\N	2025-12-05 09:50:40.404578+01	\N
14	ABS	oyster	f	\N	2025-12-05 09:59:09.283961+01	\N
15	TESTO3	oyster	f	\N	2025-12-05 10:20:41.417175+01	\N
16	OST03	oyster	f	\N	2025-12-05 10:38:59.519112+01	\N
17	OST-95	oyster	f	\N	2025-12-05 11:00:22.555088+01	\N
18	GOH1-190925-SG1-131025	oyster	f	\N	2025-12-05 13:40:18.682713+01	\N
19	GOH1-190925-SG2-131025	oyster	f	\N	2025-12-05 13:41:53.834058+01	\N
20	GOH2-190925-SG2-132025	oyster	f	\N	2025-12-05 13:45:02.426552+01	\N
21	GOH1-190925	oyster	f	\N	2025-12-05 13:47:49.541936+01	\N
22	OST-B01-25	oyster	f	\N	2025-12-05 13:49:33.997903+01	\N
23	OST-B02	oyster	f	\N	2025-12-05 13:53:04.538519+01	\N
24	GOL3-190925-SG1-131025	oyster	f	\N	2025-12-05 16:23:14.266838+01	\N
25	GOL3-190925-SG2-131025	oyster	f	\N	2025-12-05 16:24:09.739178+01	\N
26	LMH1-190925-SG1-131025	lions_mane	f	\N	2025-12-05 16:25:25.227914+01	\N
27	LMH1-190925-SG2-131025	lions_mane	f	\N	2025-12-05 16:25:55.639192+01	\N
28	LM-B01	lions_mane	f	\N	2025-12-09 10:19:58.773811+01	\N
29	LM-B03	lions_mane	f	\N	2025-12-09 11:33:01.357205+01	\N
30	SHH1-190925-SG1-131025	shiitake	f	\N	2025-12-09 11:35:22.867511+01	\N
31	SHH2-190925-SG1-131025	shiitake	f	\N	2025-12-09 11:38:20.7383+01	\N
32	SHH2-190925-SG2-131025	shiitake	f	\N	2025-12-09 11:40:24.847972+01	\N
33	SHI-B01	shiitake	f	\N	2025-12-09 11:41:51.564391+01	\N
34	OST-B03	oyster	f	\N	2025-12-17 18:11:05.657257+01	\N
35	LM-B04	lions_mane	f	\N	2025-12-17 18:11:48.728718+01	\N
36	LM-B02	lions_mane	f	\N	2025-12-18 17:53:57.816366+01	\N
37	LM-B05	lions_mane	f	\N	2025-12-29 18:23:12.382832+01	\N
38	OST-B05	oyster	f	\N	2025-12-29 18:33:41.343791+01	\N
39	OST-B06	oyster	f	\N	2025-12-29 18:34:29.26536+01	\N
40	TEST1	oyster	f	\N	2026-01-02 09:08:06.692819+01	\N
41	TEST2	oyster	f	\N	2026-01-02 09:11:37.283216+01	\N
42	TEST3	oyster	f	\N	2026-01-02 10:01:18.988713+01	\N
43	TEST5	oyster	f	\N	2026-01-02 10:02:33.136454+01	\N
44	TEST6	oyster	f	\N	2026-01-02 11:06:14.924451+01	\N
45	TEST54	oyster	f	\N	2026-01-02 11:07:25.998293+01	\N
46	TEST23	oyster	f	\N	2026-01-03 18:33:02.074715+01	\N
47	LM-B06	lions_mane	f	\N	2026-01-11 20:48:29.062192+01	\N
48	OST-B07	oyster	f	\N	2026-01-11 20:57:14.792517+01	\N
49	LM-B07	lions_mane	f	\N	2026-01-27 15:12:21.252402+01	\N
50	OST-B08	oyster	f	\N	2026-01-27 15:13:30.966184+01	\N
51	OST2175-B01	oyster	f	\N	2026-04-14 10:39:48.069469+02	\N
52	PO2181-B01	oyster	f	\N	2026-04-14 10:55:17.072774+02	\N
\.


--
-- Data for Name: batch_units; Type: TABLE DATA; Schema: public; Owner: mycoflow
--

COPY public.batch_units (id, batch_info_id, type, substrat, kg, dato_inok, status, used_in_bag, contaminated, contamination_date, created_at, updated_at, contamination_phase, contamination_notes) FROM stdin;
1	1	Grain spawn glass	Rug	0.3	2025-12-03 10:27:44.135	Inkubering	\N	f	\N	2025-12-03 11:27:50.198031+01	\N	\N	\N
2	1	Grain spawn glass	Rug	0.3	2025-12-03 10:27:44.135	Inkubering	\N	f	\N	2025-12-03 11:27:50.198031+01	\N	\N	\N
3	1	Grain spawn glass	Rug	0.3	2025-12-03 10:27:44.135	Inkubering	\N	f	\N	2025-12-03 11:27:50.198031+01	\N	\N	\N
4	1	Grain spawn glass	Rug	0.3	2025-12-03 10:27:44.135	Inkubering	\N	f	\N	2025-12-03 11:27:50.198031+01	\N	\N	\N
5	1	Grain spawn glass	Rug	0.3	2025-12-03 10:27:44.135	Inkubering	\N	f	\N	2025-12-03 11:27:50.198031+01	\N	\N	\N
6	1	Grain spawn glass	Rug	0.3	2025-12-03 10:27:44.135	Inkubering	\N	f	\N	2025-12-03 11:27:50.198031+01	\N	\N	\N
7	1	Grain spawn glass	Rug	0.3	2025-12-03 10:27:44.135	Inkubering	\N	f	\N	2025-12-03 11:27:50.198031+01	\N	\N	\N
8	1	Grain spawn glass	Rug	0.3	2025-12-03 10:27:44.135	Inkubering	\N	f	\N	2025-12-03 11:27:50.198031+01	\N	\N	\N
9	7	Grain spawn glass	Rug	0.3	2025-12-03 19:42:26.569	Inkubering	\N	f	\N	2025-12-03 20:42:32.792217+01	\N	\N	\N
10	7	Grain spawn glass	Rug	0.3	2025-12-03 19:42:41.065	Inkubering	\N	f	\N	2025-12-03 20:42:47.228659+01	\N	\N	\N
11	7	Grain spawn glass	Rug	0.3	2025-12-03 19:42:41.065	Inkubering	\N	f	\N	2025-12-03 20:42:47.228659+01	\N	\N	\N
12	7	Grain spawn glass	Rug	0.3	2025-12-03 19:42:41.065	Inkubering	\N	f	\N	2025-12-03 20:42:47.228659+01	\N	\N	\N
13	7	Grain spawn glass	Rug	0.3	2025-12-03 19:42:41.065	Inkubering	\N	f	\N	2025-12-03 20:42:47.228659+01	\N	\N	\N
14	7	Grain spawn glass	Rug	0.3	2025-12-03 19:42:41.065	Inkubering	\N	f	\N	2025-12-03 20:42:47.228659+01	\N	\N	\N
15	7	Grain spawn glass	Rug	0.3	2025-12-03 19:42:41.065	Inkubering	\N	f	\N	2025-12-03 20:42:47.228659+01	\N	\N	\N
16	7	Grain spawn glass	Rug	0.3	2025-12-03 19:42:41.065	Inkubering	\N	f	\N	2025-12-03 20:42:47.228659+01	\N	\N	\N
17	7	Grain spawn glass	Rug	0.3	2025-12-03 19:42:41.065	Inkubering	\N	f	\N	2025-12-03 20:42:47.228659+01	\N	\N	\N
18	7	Grain spawn glass	Rug	0.3	2025-12-03 19:42:41.065	Inkubering	\N	f	\N	2025-12-03 20:42:47.228659+01	\N	\N	\N
19	7	Grain spawn glass	Rug	0.3	2025-12-03 19:42:41.065	Inkubering	\N	f	\N	2025-12-03 20:42:47.228659+01	\N	\N	\N
21	14	Grain spawn glass	Rug	0.3	2025-12-05 08:59:09.793	Inkubering	\N	f	\N	2025-12-05 09:59:18.682686+01	\N	\N	\N
22	14	Grain spawn glass	Rug	0.3	2025-12-05 08:59:09.793	Inkubering	\N	f	\N	2025-12-05 09:59:18.682686+01	\N	\N	\N
23	14	Grain spawn glass	Rug	0.3	2025-12-05 08:59:09.793	Inkubering	\N	f	\N	2025-12-05 09:59:18.682686+01	\N	\N	\N
24	14	Grain spawn glass	Rug	0.3	2025-12-05 08:59:09.793	Inkubering	\N	f	\N	2025-12-05 09:59:18.682686+01	\N	\N	\N
25	14	Grain spawn glass	Rug	0.3	2025-12-05 08:59:09.793	Inkubering	\N	f	\N	2025-12-05 09:59:18.682686+01	\N	\N	\N
26	14	Grain spawn glass	Rug	0.3	2025-12-05 08:59:09.793	Inkubering	\N	f	\N	2025-12-05 09:59:18.682686+01	\N	\N	\N
27	14	Grain spawn glass	Rug	0.3	2025-12-05 08:59:09.793	Inkubering	\N	f	\N	2025-12-05 09:59:18.682686+01	\N	\N	\N
28	14	Grain spawn glass	Rug	0.3	2025-12-05 08:59:09.793	Inkubering	\N	f	\N	2025-12-05 09:59:18.682686+01	\N	\N	\N
29	14	Grain spawn glass	Rug	0.3	2025-12-05 08:59:09.793	Inkubering	\N	f	\N	2025-12-05 09:59:18.682686+01	\N	\N	\N
20	14	Grain spawn glass	Rug	0.3	2025-12-05 08:59:09.793	Inkubering	\N	f	\N	2025-12-05 09:59:18.682686+01	2025-12-05 09:59:30.693661+01	\N	\N
30	15	Grain spawn glass	Rug	0.3	2025-12-05 09:21:37.363	Inkubering	\N	f	\N	2025-12-05 10:21:46.283022+01	\N	\N	\N
31	15	Grain spawn glass	Rug	0.3	2025-12-05 09:21:37.363	Inkubering	\N	f	\N	2025-12-05 10:21:46.283022+01	\N	\N	\N
32	15	Grain spawn glass	Rug	0.3	2025-12-05 09:21:37.363	Inkubering	\N	f	\N	2025-12-05 10:21:46.283022+01	\N	\N	\N
33	15	Grain spawn glass	Rug	0.3	2025-12-05 09:21:37.363	Inkubering	\N	f	\N	2025-12-05 10:21:46.283022+01	\N	\N	\N
34	15	Grain spawn glass	Rug	0.3	2025-12-05 09:21:37.363	Inkubering	\N	f	\N	2025-12-05 10:21:46.283022+01	\N	\N	\N
35	15	Grain spawn glass	Rug	0.3	2025-12-05 09:21:37.363	Inkubering	\N	f	\N	2025-12-05 10:21:46.283022+01	\N	\N	\N
36	16	Grain spawn glass	Rug	0.3	2025-12-05 09:39:14.283	Inkubering	\N	f	\N	2025-12-05 10:39:23.148366+01	\N	\N	\N
37	16	Grain spawn glass	Rug	0.3	2025-12-05 09:39:14.283	Inkubering	\N	f	\N	2025-12-05 10:39:23.148366+01	\N	\N	\N
38	16	Grain spawn glass	Rug	0.3	2025-12-05 09:39:14.283	Inkubering	\N	f	\N	2025-12-05 10:39:23.148366+01	\N	\N	\N
39	16	Grain spawn glass	Rug	0.3	2025-12-05 09:39:14.283	Inkubering	\N	f	\N	2025-12-05 10:39:23.148366+01	\N	\N	\N
40	16	Grain spawn glass	Rug	0.3	2025-12-05 09:39:14.283	Inkubering	\N	f	\N	2025-12-05 10:39:23.148366+01	\N	\N	\N
41	16	Grain spawn glass	Rug	0.3	2025-12-05 09:39:14.283	Inkubering	\N	f	\N	2025-12-05 10:39:23.148366+01	\N	\N	\N
42	17	Grain spawn glass	Rug	0.3	2025-10-08 00:00:00	Inkubering	\N	f	\N	2025-12-05 11:00:22.612877+01	\N	\N	\N
43	17	Grain spawn glass	Rug	0.3	2025-10-08 00:00:00	Inkubering	\N	f	\N	2025-12-05 11:00:22.612877+01	\N	\N	\N
44	17	Grain spawn glass	Rug	0.3	2025-10-08 00:00:00	Inkubering	\N	f	\N	2025-12-05 11:00:22.612877+01	\N	\N	\N
45	17	Grain spawn glass	Rug	0.3	2025-10-08 00:00:00	Inkubering	\N	f	\N	2025-12-05 11:00:22.612877+01	\N	\N	\N
46	17	Grain spawn glass	Rug	0.3	2025-10-08 00:00:00	Inkubering	\N	f	\N	2025-12-05 11:00:22.612877+01	\N	\N	\N
47	17	Grain spawn glass	Rug	0.3	2025-10-08 00:00:00	Inkubering	\N	f	\N	2025-12-05 11:00:22.612877+01	\N	\N	\N
48	17	Grain spawn glass	Rug	0.3	2025-10-08 00:00:00	Inkubering	\N	f	\N	2025-12-05 11:00:22.612877+01	\N	\N	\N
49	17	Grain spawn glass	Rug	0.3	2025-10-08 00:00:00	Inkubering	\N	f	\N	2025-12-05 11:00:22.612877+01	\N	\N	\N
50	18	Grain spawn glass	Rug	0.3	2025-09-24 00:00:00	Inkubering	\N	f	\N	2025-12-05 13:40:18.748701+01	\N	\N	\N
51	19	Grain spawn glass	Rug	0.3	2025-09-24 00:00:00	Inkubering	\N	f	\N	2025-12-05 13:41:53.894784+01	\N	\N	\N
52	19	Grain spawn glass	Rug	0.3	2025-09-24 00:00:00	Inkubering	\N	f	\N	2025-12-05 13:43:26.324788+01	\N	\N	\N
53	20	Grain spawn glass	Rug	0.3	2025-09-24 00:00:00	Inkubering	\N	f	\N	2025-12-05 13:45:02.49409+01	\N	\N	\N
54	21	Grain spawn glass	Rug	0.3	2025-09-24 00:00:00	Inkubering	\N	f	\N	2025-12-05 13:47:49.603875+01	\N	\N	\N
55	21	Grain spawn glass	Rug	0.3	2025-09-24 00:00:00	Inkubering	\N	f	\N	2025-12-05 13:47:49.603875+01	\N	\N	\N
56	21	Grain spawn glass	Rug	0.3	2025-09-24 00:00:00	Inkubering	\N	f	\N	2025-12-05 13:47:49.603875+01	\N	\N	\N
57	21	Grain spawn glass	Rug	0.3	2025-09-24 00:00:00	Inkubering	\N	f	\N	2025-12-05 13:47:49.603875+01	\N	\N	\N
58	21	Grain spawn glass	Rug	0.3	2025-09-24 00:00:00	Inkubering	\N	f	\N	2025-12-05 13:47:49.603875+01	\N	\N	\N
59	21	Grain spawn glass	Rug	0.3	2025-09-24 00:00:00	Inkubering	\N	f	\N	2025-12-05 13:47:49.603875+01	\N	\N	\N
60	21	Grain spawn glass	Rug	0.3	2025-09-24 00:00:00	Inkubering	\N	f	\N	2025-12-05 13:47:49.603875+01	\N	\N	\N
61	21	Grain spawn glass	Rug	0.3	2025-09-24 00:00:00	Inkubering	\N	f	\N	2025-12-05 13:47:49.603875+01	\N	\N	\N
62	21	Grain spawn glass	Rug	0.3	2025-09-24 00:00:00	Inkubering	\N	f	\N	2025-12-05 13:47:49.603875+01	\N	\N	\N
63	22	Grain spawn glass	Rug	0.3	2025-09-19 00:00:00	Inkubering	\N	f	\N	2025-12-05 13:49:34.097099+01	\N	\N	\N
64	22	Grain spawn glass	Rug	0.3	2025-09-19 00:00:00	Inkubering	\N	f	\N	2025-12-05 13:49:34.097099+01	\N	\N	\N
65	22	Grain spawn glass	Rug	0.3	2025-09-19 00:00:00	Inkubering	\N	f	\N	2025-12-05 13:49:34.097099+01	\N	\N	\N
66	22	Grain spawn glass	Rug	0.3	2025-09-19 00:00:00	Inkubering	\N	f	\N	2025-12-05 13:49:34.097099+01	\N	\N	\N
67	22	Grain spawn glass	Rug	0.3	2025-09-19 00:00:00	Inkubering	\N	f	\N	2025-12-05 13:49:34.097099+01	\N	\N	\N
68	22	Grain spawn glass	Rug	0.3	2025-09-19 00:00:00	Inkubering	\N	f	\N	2025-12-05 13:49:34.097099+01	\N	\N	\N
69	22	Grain spawn glass	Rug	0.3	2025-09-19 00:00:00	Inkubering	\N	f	\N	2025-12-05 13:49:34.097099+01	\N	\N	\N
70	22	Grain spawn glass	Rug	0.3	2025-09-19 00:00:00	Inkubering	\N	f	\N	2025-12-05 13:49:34.097099+01	\N	\N	\N
71	22	Grain spawn glass	Rug	0.3	2025-09-19 00:00:00	Inkubering	\N	f	\N	2025-12-05 13:49:34.097099+01	\N	\N	\N
72	23	Grain spawn glass	Rug	0.3	2025-11-17 00:00:00	Inkubering	\N	f	\N	2025-12-05 13:53:04.656326+01	\N	\N	\N
73	23	Grain spawn glass	Rug	0.3	2025-11-17 00:00:00	Inkubering	\N	f	\N	2025-12-05 13:53:04.656326+01	\N	\N	\N
74	23	Grain spawn glass	Rug	0.3	2025-11-17 00:00:00	Inkubering	\N	f	\N	2025-12-05 13:53:04.656326+01	\N	\N	\N
75	23	Grain spawn glass	Rug	0.3	2025-11-17 00:00:00	Inkubering	\N	f	\N	2025-12-05 13:53:04.656326+01	\N	\N	\N
76	23	Grain spawn glass	Rug	0.3	2025-11-17 00:00:00	Inkubering	\N	f	\N	2025-12-05 13:53:04.656326+01	\N	\N	\N
77	23	Grain spawn glass	Rug	0.3	2025-11-17 00:00:00	Inkubering	\N	f	\N	2025-12-05 13:53:04.656326+01	\N	\N	\N
78	23	Grain spawn glass	Rug	0.3	2025-11-17 00:00:00	Inkubering	\N	f	\N	2025-12-05 13:53:04.656326+01	\N	\N	\N
79	23	Grain spawn glass	Rug	0.3	2025-11-17 00:00:00	Inkubering	\N	f	\N	2025-12-05 13:53:04.656326+01	\N	\N	\N
81	25	Grain spawn glass	Rug	0.3	2025-09-24 00:00:00	Inkubering	\N	f	\N	2025-12-05 16:24:09.799343+01	\N	\N	\N
102	33	Grain spawn glass	Rug	0.3	2025-10-22 00:00:00	Inkubering	\N	f	\N	2025-12-09 11:41:51.625813+01	\N	\N	\N
103	33	Grain spawn glass	Rug	0.3	2025-10-22 00:00:00	Inkubering	\N	f	\N	2025-12-09 11:41:51.625813+01	\N	\N	\N
104	33	Grain spawn glass	Rug	0.3	2025-10-22 00:00:00	Inkubering	\N	f	\N	2025-12-09 11:41:51.625813+01	\N	\N	\N
105	33	Grain spawn glass	Rug	0.3	2025-10-22 00:00:00	Inkubering	\N	f	\N	2025-12-09 11:41:51.625813+01	\N	\N	\N
80	24	Grain spawn glass	Rug	0.3	2025-09-24 00:00:00	Inkubering	\N	f	\N	2025-12-05 16:23:14.327159+01	\N	\N	\N
84	28	Grain spawn glass	Rug	0.3	2025-10-22 00:00:00	Inkubering	\N	f	\N	2025-12-09 10:19:58.842449+01	\N	\N	\N
85	28	Grain spawn glass	Rug	0.3	2025-10-22 00:00:00	Inkubering	\N	f	\N	2025-12-09 10:19:58.842449+01	\N	\N	\N
86	28	Grain spawn glass	Rug	0.3	2025-10-22 00:00:00	Inkubering	\N	f	\N	2025-12-09 10:19:58.842449+01	\N	\N	\N
87	28	Grain spawn glass	Rug	0.3	2025-10-22 00:00:00	Inkubering	\N	f	\N	2025-12-09 10:19:58.842449+01	\N	\N	\N
88	28	Grain spawn glass	Rug	0.3	2025-10-22 00:00:00	Inkubering	\N	f	\N	2025-12-09 10:19:58.842449+01	\N	\N	\N
89	28	Grain spawn glass	Rug	0.3	2025-10-22 00:00:00	Inkubering	\N	f	\N	2025-12-09 10:19:58.842449+01	\N	\N	\N
90	29	Grain spawn glass	Rug	0.3	2025-11-17 00:00:00	Inkubering	\N	f	\N	2025-12-09 11:33:01.416108+01	\N	\N	\N
91	29	Grain spawn glass	Rug	0.3	2025-11-17 00:00:00	Inkubering	\N	f	\N	2025-12-09 11:33:01.416108+01	\N	\N	\N
92	29	Grain spawn glass	Rug	0.3	2025-11-17 00:00:00	Inkubering	\N	f	\N	2025-12-09 11:33:01.416108+01	\N	\N	\N
93	29	Grain spawn glass	Rug	0.3	2025-11-17 00:00:00	Inkubering	\N	f	\N	2025-12-09 11:33:01.416108+01	\N	\N	\N
94	29	Grain spawn glass	Rug	0.3	2025-11-17 00:00:00	Inkubering	\N	f	\N	2025-12-09 11:33:01.416108+01	\N	\N	\N
95	29	Grain spawn glass	Rug	0.3	2025-11-17 00:00:00	Inkubering	\N	f	\N	2025-12-09 11:33:01.416108+01	\N	\N	\N
96	29	Grain spawn glass	Rug	0.3	2025-11-17 00:00:00	Inkubering	\N	f	\N	2025-12-09 11:33:01.416108+01	\N	\N	\N
97	29	Grain spawn glass	Rug	0.3	2025-11-17 00:00:00	Inkubering	\N	f	\N	2025-12-09 11:33:01.416108+01	\N	\N	\N
99	30	Grain spawn glass	Rug	0.3	2025-10-13 00:00:00	Inkubering	\N	f	\N	2025-12-09 11:37:05.432172+01	\N	\N	\N
82	26	Grain spawn glass	Rug	0.3	2025-10-13 00:00:00	Inkubering	\N	f	\N	2025-12-05 16:25:25.295839+01	\N	\N	\N
83	27	Grain spawn glass	Rug	0.3	2025-10-13 00:00:00	Inkubering	\N	f	\N	2025-12-05 16:25:55.698729+01	\N	\N	\N
98	30	Grain spawn glass	Rug	0.3	2025-10-13 00:00:00	Inkubering	\N	f	\N	2025-12-09 11:35:22.928136+01	\N	\N	\N
100	31	Grain spawn glass	Rug	0.3	2025-10-13 00:00:00	Inkubering	\N	f	\N	2025-12-09 11:38:20.807161+01	\N	\N	\N
101	32	Grain spawn glass	Rug	0.3	2025-10-13 00:00:00	Inkubering	\N	f	\N	2025-12-09 11:40:24.911936+01	\N	\N	\N
109	34	Grain spawn glass	Rug	0.3	2025-12-15 00:00:00	Inkubering	\N	f	\N	2025-12-17 18:11:05.742392+01	\N	\N	\N
110	34	Grain spawn glass	Rug	0.3	2025-12-15 00:00:00	Inkubering	\N	f	\N	2025-12-17 18:11:05.742392+01	\N	\N	\N
111	34	Grain spawn glass	Rug	0.3	2025-12-15 00:00:00	Inkubering	\N	f	\N	2025-12-17 18:11:05.742392+01	\N	\N	\N
131	36	Grain spawn glass	Rug	0.3	2025-11-12 00:00:00	Inkubering	\N	f	\N	2025-12-18 17:53:57.890495+01	\N	\N	\N
132	36	Grain spawn glass	Rug	0.3	2025-11-12 00:00:00	Inkubering	\N	f	\N	2025-12-18 17:53:57.890495+01	\N	\N	\N
133	36	Grain spawn glass	Rug	0.3	2025-11-12 00:00:00	Inkubering	\N	f	\N	2025-12-18 17:53:57.890495+01	\N	\N	\N
134	36	Grain spawn glass	Rug	0.3	2025-11-12 00:00:00	Inkubering	\N	f	\N	2025-12-18 17:53:57.890495+01	\N	\N	\N
135	36	Grain spawn glass	Rug	0.3	2025-11-12 00:00:00	Inkubering	\N	f	\N	2025-12-18 17:53:57.890495+01	\N	\N	\N
136	36	Grain spawn glass	Rug	0.3	2025-11-12 00:00:00	Inkubering	\N	f	\N	2025-12-18 17:53:57.890495+01	\N	\N	\N
137	36	Grain spawn glass	Rug	0.3	2025-11-12 00:00:00	Inkubering	\N	f	\N	2025-12-18 17:53:57.890495+01	\N	\N	\N
139	35	Grain spawn glass	Rug	0.3	2025-12-15 00:00:00	Inkubering	\N	f	\N	2025-12-25 14:58:26.839422+01	\N	\N	\N
140	35	Grain spawn glass	Rug	0.3	2025-12-15 00:00:00	Inkubering	\N	f	\N	2025-12-25 14:58:26.839422+01	\N	\N	\N
141	35	Grain spawn glass	Rug	0.3	2025-12-15 00:00:00	Inkubering	\N	f	\N	2025-12-25 14:58:26.839422+01	\N	\N	\N
142	35	Grain spawn glass	Rug	0.3	2025-12-15 00:00:00	Inkubering	\N	f	\N	2025-12-25 14:58:26.839422+01	\N	\N	\N
143	35	Grain spawn glass	Rug	0.3	2025-12-15 00:00:00	Inkubering	\N	f	\N	2025-12-25 14:58:26.839422+01	\N	\N	\N
144	35	Grain spawn glass	Rug	0.3	2025-12-15 00:00:00	Inkubering	\N	f	\N	2025-12-25 14:58:26.839422+01	\N	\N	\N
145	35	Grain spawn glass	Rug	0.3	2025-12-15 00:00:00	Inkubering	\N	f	\N	2025-12-25 14:58:26.839422+01	\N	\N	\N
146	35	Grain spawn glass	Rug	0.3	2025-12-15 00:00:00	Inkubering	\N	f	\N	2025-12-25 14:58:26.839422+01	\N	\N	\N
147	35	Grain spawn glass	Rug	0.3	2025-12-15 00:00:00	Inkubering	\N	f	\N	2025-12-25 14:58:26.839422+01	\N	\N	\N
148	35	Grain spawn glass	Rug	0.3	2025-12-15 00:00:00	Inkubering	\N	f	\N	2025-12-25 14:58:26.839422+01	\N	\N	\N
149	35	Grain spawn glass	Rug	0.3	2025-12-15 00:00:00	Inkubering	\N	f	\N	2025-12-25 14:58:26.839422+01	\N	\N	\N
152	34	Grain spawn glass	Rug	0.3	2025-12-15 00:00:00	Inkubering	\N	f	\N	2025-12-25 14:59:03.15648+01	\N	\N	\N
153	34	Grain spawn glass	Rug	0.3	2025-12-15 00:00:00	Inkubering	\N	f	\N	2025-12-25 14:59:03.15648+01	\N	\N	\N
157	34	Grain spawn glass	Rug	0.3	2025-12-15 00:00:00	Inkubering	\N	f	\N	2025-12-25 14:59:03.15648+01	\N	\N	\N
158	34	Grain spawn glass	Rug	0.3	2025-12-15 00:00:00	Inkubering	\N	f	\N	2025-12-25 14:59:03.15648+01	\N	\N	\N
159	34	Grain spawn glass	Rug	0.3	2025-12-15 00:00:00	Inkubering	\N	f	\N	2025-12-25 14:59:03.15648+01	\N	\N	\N
160	34	Grain spawn glass	Rug	0.3	2025-12-15 00:00:00	Inkubering	\N	f	\N	2025-12-25 14:59:03.15648+01	\N	\N	\N
161	34	Grain spawn glass	Rug	0.3	2025-12-26 14:54:38.498	Inkubering	\N	f	\N	2025-12-26 15:54:46.165116+01	\N	\N	\N
162	34	Grain spawn glass	Rug	0.3	2025-12-26 14:54:43.106	Inkubering	\N	f	\N	2025-12-26 15:54:50.847853+01	\N	\N	\N
163	35	Grain spawn glass	Rug	0.3	2025-12-26 14:55:17.427	Inkubering	\N	f	\N	2025-12-26 15:55:25.160977+01	\N	\N	\N
129	36	Grain spawn glass	Rug	0.3	2025-11-12 00:00:00	Inkubering	\N	f	\N	2025-12-18 17:53:57.890495+01	2025-12-26 18:35:35.363736+01	\N	\N
130	36	Grain spawn glass	Rug	0.3	2025-11-12 00:00:00	Inkubering	\N	f	\N	2025-12-18 17:53:57.890495+01	2025-12-26 18:35:59.06217+01	\N	\N
164	37	Grain spawn glass	Rug	0.3	2025-12-29 00:00:00	Inkubering	\N	f	\N	2025-12-29 18:23:12.467838+01	\N	\N	\N
165	37	Grain spawn glass	Rug	0.3	2025-12-29 00:00:00	Inkubering	\N	f	\N	2025-12-29 18:23:12.467838+01	\N	\N	\N
166	37	Grain spawn glass	Rug	0.3	2025-12-29 00:00:00	Inkubering	\N	f	\N	2025-12-29 18:23:12.467838+01	\N	\N	\N
167	37	Grain spawn glass	Rug	0.3	2025-12-29 00:00:00	Inkubering	\N	f	\N	2025-12-29 18:23:12.467838+01	\N	\N	\N
168	37	Grain spawn glass	Rug	0.3	2025-12-29 00:00:00	Inkubering	\N	f	\N	2025-12-29 18:23:12.467838+01	\N	\N	\N
169	37	Grain spawn glass	Rug	0.3	2025-12-29 00:00:00	Inkubering	\N	f	\N	2025-12-29 18:23:12.467838+01	\N	\N	\N
170	37	Grain spawn glass	Rug	0.3	2025-12-29 00:00:00	Inkubering	\N	f	\N	2025-12-29 18:23:12.467838+01	\N	\N	\N
171	37	Grain spawn glass	Rug	0.3	2025-12-29 00:00:00	Inkubering	\N	f	\N	2025-12-29 18:23:12.467838+01	\N	\N	\N
172	37	Grain spawn glass	Rug	0.3	2025-12-29 00:00:00	Inkubering	\N	f	\N	2025-12-29 18:23:12.467838+01	\N	\N	\N
173	37	Grain spawn glass	Rug	0.3	2025-12-29 00:00:00	Inkubering	\N	f	\N	2025-12-29 18:23:12.467838+01	\N	\N	\N
174	38	Grain spawn glass	Rug	0.3	2025-12-29 00:00:00	Inkubering	\N	f	\N	2025-12-29 18:33:41.441275+01	\N	\N	\N
175	38	Grain spawn glass	Rug	0.3	2025-12-29 00:00:00	Inkubering	\N	f	\N	2025-12-29 18:33:41.441275+01	\N	\N	\N
176	38	Grain spawn glass	Rug	0.3	2025-12-29 00:00:00	Inkubering	\N	f	\N	2025-12-29 18:33:41.441275+01	\N	\N	\N
177	38	Grain spawn glass	Rug	0.3	2025-12-29 00:00:00	Inkubering	\N	f	\N	2025-12-29 18:33:41.441275+01	\N	\N	\N
178	39	Grain spawn glass	Rug	0.3	2025-12-29 00:00:00	Inkubering	\N	f	\N	2025-12-29 18:34:29.347701+01	\N	\N	\N
179	39	Grain spawn glass	Rug	0.3	2025-12-29 00:00:00	Inkubering	\N	f	\N	2025-12-29 18:34:29.347701+01	\N	\N	\N
180	39	Grain spawn glass	Rug	0.3	2025-12-29 00:00:00	Inkubering	\N	f	\N	2025-12-29 18:34:29.347701+01	\N	\N	\N
181	39	Grain spawn glass	Rug	0.3	2025-12-29 00:00:00	Inkubering	\N	f	\N	2025-12-29 18:34:29.347701+01	\N	\N	\N
182	39	Grain spawn glass	Rug	0.3	2025-12-29 00:00:00	Inkubering	\N	f	\N	2025-12-29 18:34:29.347701+01	\N	\N	\N
183	39	Grain spawn glass	Rug	0.3	2025-12-29 00:00:00	Inkubering	\N	f	\N	2025-12-29 18:34:29.347701+01	\N	\N	\N
186	40	Grain spawn glass	Hvete	0.5	2026-01-02 00:00:00	Inkubering	\N	f	\N	2026-01-02 09:08:06.789908+01	\N	\N	\N
187	40	Grain spawn glass	Hvete	0.5	2026-01-02 00:00:00	Inkubering	\N	f	\N	2026-01-02 09:08:06.789908+01	\N	\N	\N
184	40	Grain spawn glass	Hvete	0.5	2026-01-02 00:00:00	Inkubering	\N	f	\N	2026-01-02 09:08:06.789908+01	2026-01-02 09:09:17.586566+01	\N	\N
188	40	Grain spawn glass	Rug	0.3	2026-01-02 08:09:17.181	Inkubering	\N	f	\N	2026-01-02 09:09:33.453087+01	\N	\N	\N
189	40	Grain spawn glass	Rug	0.3	2026-01-02 08:09:18.821	Inkubering	\N	f	\N	2026-01-02 09:09:35.091755+01	\N	\N	\N
190	41	Grain spawn glass	Rug	0.3	2026-01-02 00:00:00	Inkubering	\N	t	2026-01-02 08:13:25.919528	2026-01-02 09:11:37.347744+01	2026-01-02 09:13:25.914447+01	\N	\N
185	40	Grain spawn glass	Hvete	0.5	2026-01-02 00:00:00	Inkubering	\N	t	2026-01-02 08:18:56.646838	2026-01-02 09:08:06.789908+01	2026-01-02 09:18:56.641641+01	\N	\N
191	8	Grain spawn glass	Rug	0.3	2025-12-02 00:00:00	Inkubering	\N	f	\N	2026-01-02 09:30:45.760674+01	\N	\N	\N
192	42	Grain spawn glass	Rug	0.3	2025-12-02 00:00:00	Inkubering	\N	f	\N	2026-01-02 10:01:19.048263+01	\N	\N	\N
193	42	Grain spawn glass	Rug	0.3	2025-12-02 00:00:00	Inkubering	\N	f	\N	2026-01-02 10:01:19.048263+01	\N	\N	\N
194	42	Grain spawn glass	Rug	0.3	2025-12-02 00:00:00	Inkubering	\N	f	\N	2026-01-02 10:01:19.048263+01	\N	\N	\N
195	42	Grain spawn glass	Rug	0.3	2025-12-02 00:00:00	Inkubering	\N	f	\N	2026-01-02 10:01:19.048263+01	\N	\N	\N
196	42	Grain spawn glass	Rug	0.3	2025-12-02 00:00:00	Inkubering	\N	f	\N	2026-01-02 10:01:19.048263+01	\N	\N	\N
197	42	Grain spawn glass	Rug	0.3	2025-12-02 00:00:00	Inkubering	\N	f	\N	2026-01-02 10:01:19.048263+01	\N	\N	\N
198	43	Grain spawn glass	Rug	0.3	2026-12-02 00:00:00	Inkubering	\N	f	\N	2026-01-02 10:02:33.201708+01	\N	\N	\N
199	43	Grain spawn glass	Rug	0.3	2026-12-02 00:00:00	Inkubering	\N	f	\N	2026-01-02 10:02:33.201708+01	\N	\N	\N
200	43	Grain spawn glass	Rug	0.3	2026-12-02 00:00:00	Inkubering	\N	f	\N	2026-01-02 10:02:33.201708+01	\N	\N	\N
201	43	Grain spawn glass	Rug	0.3	2026-12-02 00:00:00	Inkubering	\N	f	\N	2026-01-02 10:02:33.201708+01	\N	\N	\N
202	43	Grain spawn glass	Rug	0.3	2026-12-02 00:00:00	Inkubering	\N	f	\N	2026-01-02 10:02:33.201708+01	\N	\N	\N
203	43	Grain spawn glass	Rug	0.3	2026-12-02 00:00:00	Inkubering	\N	f	\N	2026-01-02 10:02:33.201708+01	\N	\N	\N
204	43	Grain spawn glass	Rug	0.3	2026-12-02 00:00:00	Inkubering	\N	f	\N	2026-01-02 10:02:33.201708+01	\N	\N	\N
205	43	Grain spawn glass	Rug	0.3	2026-12-02 00:00:00	Inkubering	\N	f	\N	2026-01-02 10:02:33.201708+01	\N	\N	\N
206	44	Grain spawn glass	Rug	0.3	2025-12-02 00:00:00	Inkubering	\N	f	\N	2026-01-02 11:06:14.987192+01	\N	\N	\N
207	44	Grain spawn glass	Rug	0.3	2025-12-02 00:00:00	Inkubering	\N	f	\N	2026-01-02 11:06:14.987192+01	\N	\N	\N
208	44	Grain spawn glass	Rug	0.3	2025-12-02 00:00:00	Inkubering	\N	f	\N	2026-01-02 11:06:14.987192+01	\N	\N	\N
209	44	Grain spawn glass	Rug	0.3	2025-12-02 00:00:00	Inkubering	\N	f	\N	2026-01-02 11:06:14.987192+01	\N	\N	\N
210	44	Grain spawn glass	Rug	0.3	2025-12-02 00:00:00	Inkubering	\N	f	\N	2026-01-02 11:06:14.987192+01	\N	\N	\N
211	45	Grain spawn glass	Rug	0.3	2025-12-02 00:00:00	Inkubering	\N	f	\N	2026-01-02 11:07:26.136016+01	\N	\N	\N
212	45	Grain spawn glass	Rug	0.3	2025-12-02 00:00:00	Inkubering	\N	f	\N	2026-01-02 11:07:26.136016+01	\N	\N	\N
213	45	Grain spawn glass	Rug	0.3	2025-12-02 00:00:00	Inkubering	\N	f	\N	2026-01-02 11:07:26.136016+01	\N	\N	\N
214	45	Grain spawn glass	Rug	0.3	2025-12-02 00:00:00	Inkubering	\N	f	\N	2026-01-02 11:07:26.136016+01	\N	\N	\N
215	45	Grain spawn glass	Rug	0.3	2025-12-02 00:00:00	Inkubering	\N	f	\N	2026-01-02 11:07:26.136016+01	\N	\N	\N
216	46	Grain spawn glass	Rug	0.3	2025-12-03 00:00:00	Inkubering	\N	f	\N	2026-01-03 18:33:02.17586+01	\N	\N	\N
217	46	Grain spawn glass	Rug	0.3	2025-12-03 00:00:00	Inkubering	\N	f	\N	2026-01-03 18:33:02.17586+01	\N	\N	\N
218	46	Grain spawn glass	Rug	0.3	2025-12-03 00:00:00	Inkubering	\N	f	\N	2026-01-03 18:33:02.17586+01	\N	\N	\N
220	46	Grain spawn glass	Rug	0.3	2025-12-03 00:00:00	Inkubering	\N	f	\N	2026-01-03 18:33:02.17586+01	\N	\N	\N
221	46	Grain spawn glass	Rug	0.3	2025-12-03 00:00:00	Inkubering	\N	f	\N	2026-01-03 18:33:02.17586+01	\N	\N	\N
219	46	Grain spawn glass	Rug	0.3	2025-12-03 00:00:00	Inkubering	\N	t	2026-01-03 17:35:15.913379	2026-01-03 18:33:02.17586+01	2026-01-03 18:35:15.905954+01	\N	\N
222	47	Grain spawn glass	Rug	0.3	2026-01-11 00:00:00	Inkubering	\N	f	\N	2026-01-11 20:48:29.147937+01	\N	\N	\N
223	47	Grain spawn glass	Rug	0.3	2026-01-11 00:00:00	Inkubering	\N	f	\N	2026-01-11 20:48:29.147937+01	\N	\N	\N
224	47	Grain spawn glass	Rug	0.3	2026-01-11 00:00:00	Inkubering	\N	f	\N	2026-01-11 20:48:29.147937+01	\N	\N	\N
225	47	Grain spawn glass	Rug	0.3	2026-01-11 00:00:00	Inkubering	\N	f	\N	2026-01-11 20:48:29.147937+01	\N	\N	\N
226	47	Grain spawn glass	Rug	0.3	2026-01-11 00:00:00	Inkubering	\N	f	\N	2026-01-11 20:48:29.147937+01	\N	\N	\N
227	47	Grain spawn glass	Rug	0.3	2026-01-11 00:00:00	Inkubering	\N	f	\N	2026-01-11 20:48:29.147937+01	\N	\N	\N
228	47	Grain spawn glass	Rug	0.3	2026-01-11 00:00:00	Inkubering	\N	f	\N	2026-01-11 20:48:29.147937+01	\N	\N	\N
229	47	Grain spawn glass	Rug	0.3	2026-01-11 00:00:00	Inkubering	\N	f	\N	2026-01-11 20:48:29.147937+01	\N	\N	\N
230	47	Grain spawn glass	Rug	0.3	2026-01-11 00:00:00	Inkubering	\N	f	\N	2026-01-11 20:48:29.147937+01	\N	\N	\N
231	47	Grain spawn glass	Rug	0.3	2026-01-11 00:00:00	Inkubering	\N	f	\N	2026-01-11 20:48:29.147937+01	\N	\N	\N
232	48	Grain spawn glass	Rug	0.3	2026-01-11 00:00:00	Inkubering	\N	f	\N	2026-01-11 20:57:14.856416+01	\N	\N	\N
233	48	Grain spawn glass	Rug	0.3	2026-01-11 00:00:00	Inkubering	\N	f	\N	2026-01-11 20:57:14.856416+01	\N	\N	\N
234	48	Grain spawn glass	Rug	0.3	2026-01-11 00:00:00	Inkubering	\N	f	\N	2026-01-11 20:57:14.856416+01	\N	\N	\N
235	48	Grain spawn glass	Rug	0.3	2026-01-11 00:00:00	Inkubering	\N	f	\N	2026-01-11 20:57:14.856416+01	\N	\N	\N
236	48	Grain spawn glass	Rug	0.3	2026-01-11 00:00:00	Inkubering	\N	f	\N	2026-01-11 20:57:14.856416+01	\N	\N	\N
237	48	Grain spawn glass	Rug	0.3	2026-01-11 00:00:00	Inkubering	\N	f	\N	2026-01-11 20:57:14.856416+01	\N	\N	\N
238	48	Grain spawn glass	Rug	0.3	2026-01-11 00:00:00	Inkubering	\N	f	\N	2026-01-11 20:57:14.856416+01	\N	\N	\N
239	48	Grain spawn glass	Rug	0.3	2026-01-11 00:00:00	Inkubering	\N	f	\N	2026-01-11 20:57:14.856416+01	\N	\N	\N
240	48	Grain spawn glass	Rug	0.3	2026-01-11 00:00:00	Inkubering	\N	f	\N	2026-01-11 20:57:14.856416+01	\N	\N	\N
241	48	Grain spawn glass	Rug	0.3	2026-01-11 00:00:00	Inkubering	\N	f	\N	2026-01-11 20:57:14.856416+01	\N	\N	\N
242	49	Grain spawn glass	Rug	0.3	2026-01-27 00:00:00	Inkubering	\N	f	\N	2026-01-27 15:12:21.346812+01	\N	\N	\N
243	49	Grain spawn glass	Rug	0.3	2026-01-27 00:00:00	Inkubering	\N	f	\N	2026-01-27 15:12:21.346812+01	\N	\N	\N
244	49	Grain spawn glass	Rug	0.3	2026-01-27 00:00:00	Inkubering	\N	f	\N	2026-01-27 15:12:21.346812+01	\N	\N	\N
245	49	Grain spawn glass	Rug	0.3	2026-01-27 00:00:00	Inkubering	\N	f	\N	2026-01-27 15:12:21.346812+01	\N	\N	\N
246	49	Grain spawn glass	Rug	0.3	2026-01-27 00:00:00	Inkubering	\N	f	\N	2026-01-27 15:12:21.346812+01	\N	\N	\N
247	49	Grain spawn glass	Rug	0.3	2026-01-27 00:00:00	Inkubering	\N	f	\N	2026-01-27 15:12:21.346812+01	\N	\N	\N
248	49	Grain spawn glass	Rug	0.3	2026-01-27 00:00:00	Inkubering	\N	f	\N	2026-01-27 15:12:21.346812+01	\N	\N	\N
249	49	Grain spawn glass	Rug	0.3	2026-01-27 00:00:00	Inkubering	\N	f	\N	2026-01-27 15:12:21.346812+01	\N	\N	\N
250	50	Grain spawn glass	Rug	0.3	2026-01-27 00:00:00	Inkubering	\N	f	\N	2026-01-27 15:13:31.040581+01	\N	\N	\N
251	50	Grain spawn glass	Rug	0.3	2026-01-27 00:00:00	Inkubering	\N	f	\N	2026-01-27 15:13:31.040581+01	\N	\N	\N
252	50	Grain spawn glass	Rug	0.3	2026-01-27 00:00:00	Inkubering	\N	f	\N	2026-01-27 15:13:31.040581+01	\N	\N	\N
253	50	Grain spawn glass	Rug	0.3	2026-01-27 00:00:00	Inkubering	\N	f	\N	2026-01-27 15:13:31.040581+01	\N	\N	\N
254	50	Grain spawn glass	Rug	0.3	2026-01-27 00:00:00	Inkubering	\N	f	\N	2026-01-27 15:13:31.040581+01	\N	\N	\N
255	50	Grain spawn glass	Rug	0.3	2026-01-27 00:00:00	Inkubering	\N	f	\N	2026-01-27 15:13:31.040581+01	\N	\N	\N
256	50	Grain spawn glass	Rug	0.3	2026-01-27 00:00:00	Inkubering	\N	f	\N	2026-01-27 15:13:31.040581+01	\N	\N	\N
257	50	Grain spawn glass	Rug	0.3	2026-01-27 00:00:00	Inkubering	\N	f	\N	2026-01-27 15:13:31.040581+01	\N	\N	\N
258	50	Grain spawn glass	Rug	0.3	2026-01-27 00:00:00	Inkubering	\N	f	\N	2026-01-27 15:13:31.040581+01	\N	\N	\N
259	50	Grain spawn glass	Rug	0.3	2026-01-27 00:00:00	Inkubering	\N	f	\N	2026-01-27 15:13:31.040581+01	\N	\N	\N
260	51	Grain spawn glass	Rug	0.3	2026-04-14 02:00:00	Inkubering	\N	f	\N	2026-04-14 10:39:48.180482+02	\N	\N	\N
261	51	Grain spawn glass	Rug	0.3	2026-04-14 02:00:00	Inkubering	\N	f	\N	2026-04-14 10:39:48.180482+02	\N	\N	\N
262	51	Grain spawn glass	Rug	0.3	2026-04-14 02:00:00	Inkubering	\N	f	\N	2026-04-14 10:39:48.180482+02	\N	\N	\N
263	51	Grain spawn glass	Rug	0.3	2026-04-14 02:00:00	Inkubering	\N	f	\N	2026-04-14 10:39:48.180482+02	\N	\N	\N
264	51	Grain spawn glass	Rug	0.3	2026-04-14 02:00:00	Inkubering	\N	f	\N	2026-04-14 10:39:48.180482+02	\N	\N	\N
265	51	Grain spawn glass	Rug	0.3	2026-04-14 02:00:00	Inkubering	\N	f	\N	2026-04-14 10:39:48.180482+02	\N	\N	\N
266	51	Grain spawn glass	Rug	0.3	2026-04-14 02:00:00	Inkubering	\N	f	\N	2026-04-14 10:39:48.180482+02	\N	\N	\N
267	51	Grain spawn glass	Rug	0.3	2026-04-14 02:00:00	Inkubering	\N	f	\N	2026-04-14 10:39:48.180482+02	\N	\N	\N
268	51	Grain spawn glass	Rug	0.3	2026-04-14 02:00:00	Inkubering	\N	f	\N	2026-04-14 10:39:48.180482+02	\N	\N	\N
269	51	Grain spawn glass	Rug	0.3	2026-04-14 02:00:00	Inkubering	\N	f	\N	2026-04-14 10:39:48.180482+02	\N	\N	\N
270	51	Grain spawn glass	Rug	0.3	2026-04-14 02:00:00	Inkubering	\N	f	\N	2026-04-14 10:39:48.180482+02	\N	\N	\N
271	52	Grain spawn glass	Rug	0.3	2026-04-14 02:00:00	Inkubering	\N	f	\N	2026-04-14 10:55:17.16281+02	\N	\N	\N
272	52	Grain spawn glass	Rug	0.3	2026-04-14 02:00:00	Inkubering	\N	f	\N	2026-04-14 10:55:17.16281+02	\N	\N	\N
273	52	Grain spawn glass	Rug	0.3	2026-04-14 02:00:00	Inkubering	\N	f	\N	2026-04-14 10:55:17.16281+02	\N	\N	\N
274	52	Grain spawn glass	Rug	0.3	2026-04-14 02:00:00	Inkubering	\N	f	\N	2026-04-14 10:55:17.16281+02	\N	\N	\N
275	52	Grain spawn glass	Rug	0.3	2026-04-14 02:00:00	Inkubering	\N	f	\N	2026-04-14 10:55:17.16281+02	\N	\N	\N
276	52	Grain spawn glass	Rug	0.3	2026-04-14 02:00:00	Inkubering	\N	f	\N	2026-04-14 10:55:17.16281+02	\N	\N	\N
277	52	Grain spawn glass	Rug	0.3	2026-04-14 02:00:00	Inkubering	\N	f	\N	2026-04-14 10:55:17.16281+02	\N	\N	\N
278	52	Grain spawn glass	Rug	0.3	2026-04-14 02:00:00	Inkubering	\N	f	\N	2026-04-14 10:55:17.16281+02	\N	\N	\N
279	52	Grain spawn glass	Rug	0.3	2026-04-14 02:00:00	Inkubering	\N	f	\N	2026-04-14 10:55:17.16281+02	\N	\N	\N
280	52	Grain spawn glass	Rug	0.3	2026-04-14 02:00:00	Inkubering	\N	f	\N	2026-04-14 10:55:17.16281+02	\N	\N	\N
281	52	Grain spawn glass	Rug	0.3	2026-04-14 02:00:00	Inkubering	\N	f	\N	2026-04-14 10:55:17.16281+02	\N	\N	\N
\.


--
-- Data for Name: batches; Type: TABLE DATA; Schema: public; Owner: mycoflow
--

COPY public.batches (id, batch_type, strain_name, lc_batch, lc_vol, lc_dato_inok, spawn_batch, spawn_type, spawn_dato_inok, spawn_kg, spawn_dager_ink, bag_batch, bag_forventet_kolon, bag_substrat_type, bag_kg_substrat, bag_dato_inok, bag_dager_ink, bag_status, bag_frukting_start, bag_temp_kammer, bag_lf_kammer, bag_host1_start, bag_host1_slutt, bag_host1_total_kg, bag_host1_dager, bag_host2_start, bag_host2_slutt, bag_host2_total_kg, bag_host2_dager, bag_syklus_lengde, bag_be_percent, archived, notes, created_at, updated_at, qr_code, qr_data, label_printed, label_printed_at, label_print_count, workflow_status, in_fridge, fridge_date, spawn_forventet_ferdig, lc_id, bag_temp, spawn_expected_ready_date, spawn_actual_ready_date, colonization_expected_date, colonization_actual_date, colonization_temp_c, fruiting_start_date, fruiting_temp_c, flush1_expected_date, flush1_actual_start_date, flush1_harvest_date, flush1_expected_kg, flush1_actual_kg, flush2_expected_date, flush2_actual_start_date, flush2_harvest_date, flush2_expected_kg, flush2_actual_kg, flush3_expected_date, flush3_actual_start_date, flush3_harvest_date, flush3_harvest_kg, contaminated_units, bag_antall_bager, spawn_contaminated_units, bag_contaminated_units, inkubering_contaminated_units, frukt1_contaminated_units, frukt2_contaminated_units, spawn_contamination_type, inkubering_contamination_type, frukt1_contamination_type, frukt2_contamination_type, spawn_abortert, inkubering_abortert, frukt1_abortert, frukt2_abortert) FROM stdin;
69	Spawn	oyster	PO2175-LC-2614A	5ml	\N	OST2175-B01	Grain spawn glass	2026-04-14 02:00:00	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	2026-04-14 10:39:48.057829+02	2026-04-14 10:39:48.06348+02	SOPP-69	{"id": 69, "spawn_batch": "OST2175-B01", "strain": "oyster", "lc": "PO2175-LC-2614A"}	f	\N	0	spawning	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	f	f
53	Bag	oyster	GOH2	5ml	\N	OST-B03	Grain spawn glass	2025-12-15 00:00:00	\N	77	OST-B03	\N	Lusernemix forsøk 1	18	2026-01-01 11:00:00	59	Inokulert	2026-01-16 08:50:43.911	16	95	2026-01-28 19:15:05.39	2026-02-06 19:11:28.334	8	21	2026-02-09 11:00:00	2026-02-23 11:00:00	3.6	16	53	64.4	t	Østers forsøk 1	2025-12-25 14:59:02.994081+01	2026-03-26 14:32:49.699071+01	SOPP-53	{"id": 53, "spawn_batch": "OST-B03", "strain": "oyster", "lc": "GOH2"}	f	\N	0	fruiting	t	2025-12-25 15:25:18.045	\N	\N	22	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	20	0	\N	0	1	0	\N	\N	Grønn mugg	\N	f	f	f	f
54	Bag	lions_mane	LMH1	5ml	\N	LM-B05	Grain spawn glass	2025-12-29 00:00:00	\N	72	LM-B05	\N	Lusernemix Forsøk 2	9.9	2026-01-23 11:00:00	47	Inokulert	2026-02-10 14:47:52.666	16	95	2026-02-08 11:00:00	2026-02-27 11:00:00	2.2	16	2026-02-23 11:00:00	2026-03-05 11:00:00	2.8	6	41	50.5	t	LM forsøk 2	2025-12-29 18:23:12.346761+01	2026-03-26 14:32:49.699071+01	SOPP-54	{"id": 54, "spawn_batch": "LM-B05", "strain": "lions_mane", "lc": "LMH1"}	f	\N	0	fruiting	t	2026-01-18 18:43:20.097	\N	\N	22	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	11	0	\N	0	4	0	\N	\N	Wet spot	\N	f	f	f	f
66	Bag	oyster	GOL3	5ml	\N	OST-B07	Grain spawn glass	2026-01-11 00:00:00	\N	50	OST-B07	\N	Lusernemix forsøk 3	17.1	2026-01-31 11:00:00	29	Inokulert	2026-02-20 11:00:00	17	95	2026-02-25 11:00:00	2026-02-28 11:00:00	7.7	8	\N	\N	\N	\N	\N	45	t	Østers forsøk 3	2026-01-11 20:57:14.768214+01	2026-03-26 14:32:49.699071+01	SOPP-66	{"id": 66, "spawn_batch": "OST-B07", "strain": "oyster", "lc": "GOL3"}	f	\N	0	fruiting	t	2026-01-19 14:48:27.321	\N	\N	22	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	19	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	f	f
55	Bag	oyster	GOH2	5ml	\N	OST-B05	Grain spawn glass	2025-12-29 00:00:00	\N	72	OST-B05	\N	Lusernemix forsøk 1	17.1	2026-01-19 13:49:06.388	51	Inokulert	2026-02-06 18:14:12.263	16	95	2026-02-12 11:00:00	2026-02-21 11:00:00	9.3	14	2026-02-23 11:00:00	2026-02-28 11:00:00	2.8	7	39	70.8	t	Østers Forsøk 2	2025-12-29 18:33:41.319943+01	2026-03-26 14:32:49.699071+01	SOPP-55	{"id": 55, "spawn_batch": "OST-B05", "strain": "oyster", "lc": "GOH2"}	f	\N	0	fruiting	t	2026-01-07 20:24:32.125	\N	\N	22	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	19	0	\N	0	0	2	\N	\N	\N	Wet spot	f	f	f	f
52	Bag	lions_mane	LMH1	5ml	\N	LM-B04	Grain spawn glass	2025-12-15 00:00:00	\N	101	LM-B04	\N	Lusernemix Forsøk 2	18	2026-01-05 16:00:20.682	79	Inokulert	2026-01-24 11:00:00	16	95	2026-02-05 11:00:00	2026-02-06 19:11:10.985	5.5	13	2026-02-23 11:00:00	2026-02-24 11:00:00	0.8	17	49	35	t	LM Forsøk 1	2025-12-25 14:58:26.619221+01	2026-03-26 14:32:49.699071+01	SOPP-52	{"id": 52, "spawn_batch": "LM-B04", "strain": "lions_mane", "lc": "LMH1"}	f	\N	0	fruiting	f	\N	\N	\N	22	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	f	f
70	Spawn	oyster	PO2181-LC_2614A	5ml	\N	PO2181-B01	Grain spawn glass	2026-04-14 02:00:00	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	2026-04-14 10:55:17.059583+02	2026-04-14 10:55:17.06552+02	SOPP-70	{"id": 70, "spawn_batch": "PO2181-B01", "strain": "oyster", "lc": "PO2181-LC_2614A"}	f	\N	0	spawning	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	f	f
67	Bag	lions_mane	LMH1	3ml	\N	LM-B07	Grain spawn glass	2026-01-27 00:00:00	\N	78	LM-B07	\N	Lusernemix LM forsøk 4	7.2	2026-03-31 17:40:52.003	14	Inokulert	2026-04-15 09:56:46.554	15	95	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	2026-01-27 15:12:21.212125+01	2026-04-15 09:56:58.622308+02	SOPP-67	{"id": 67, "spawn_batch": "LM-B07", "strain": "lions_mane", "lc": "LMH1"}	f	\N	0	fruiting	t	2026-02-19 16:15:34.124	\N	\N	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	8	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	f	f
65	Spawn	lions_mane	LMH1	5ml	\N	LM-B06	Grain spawn glass	2026-01-11 00:00:00	\N	94	LM-B06	\N	Lusernemix LM forsøk 4	9	2026-03-31 12:00:00	14	\N	2026-04-15 09:56:48.442	15	95	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	2026-01-11 20:48:29.025645+01	2026-04-15 09:57:05.306766+02	SOPP-65	{"id": 65, "spawn_batch": "LM-B06", "strain": "lions_mane", "lc": "LMH1"}	f	\N	0	fruiting	t	2026-01-31 11:37:36.3	\N	\N	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	10	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	f	f
68	Bag	oyster	GOL3	3ml	\N	OST-B08	Grain spawn glass	2026-01-27 00:00:00	\N	74	OST-B08	\N	Luserne mix forsøk 4 Ø	9	2026-04-11 11:07:59.571	0	Inokulert	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	2026-01-27 15:13:30.940376+01	2026-04-11 11:10:02.561909+02	SOPP-68	{"id": 68, "spawn_batch": "OST-B08", "strain": "oyster", "lc": "GOL3"}	f	\N	0	colonizing	t	2026-02-05 18:18:04.822	\N	\N	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	16	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	f	f	f
\.


--
-- Data for Name: contamination_log; Type: TABLE DATA; Schema: public; Owner: mycoflow
--

COPY public.contamination_log (id, lc_code, strain_name, batch_id, batch_unit_id, contamination_phase, contamination_date, batch_type, batch_identifier, substrat_type, notes, created_at) FROM stdin;
\.


--
-- Data for Name: lc_cultures; Type: TABLE DATA; Schema: public; Owner: mycoflow
--

COPY public.lc_cultures (id, lc_code, strain_name, source, date_created, notes, active, created_at) FROM stdin;
2	GOH2	oyster	Agar plate #2	2024-11-01	\N	t	2025-12-04 14:12:25.888862
6	LMH1	lions_mane	Syringe	2025-09-19		t	2025-12-05 15:20:18.693987
4	SHI1	shiitake	Agar plate #1	2024-10-01	\N	f	2025-12-04 14:12:25.888862
5	SHI2	shiitake	Agar plate #2	2024-11-10	\N	f	2025-12-04 14:12:25.888862
7	SHH2	shiitake	Syringe	2025-09-19		t	2025-12-05 15:21:53.747832
8	SHH1	shiitake	Syringe	2025-09-19		t	2025-12-05 15:22:10.541828
9	GOL3	oyster	Syringe	2025-09-19		t	2025-12-05 15:22:38.835996
3	LOM1	lions_mane	Agar plate #1	2024-09-20	\N	f	2025-12-04 14:12:25.888862
1	GOH1	oyster	Agar plate #1	2024-10-15	\N	t	2025-12-04 14:12:25.888862
10	TEST	oyster	TEST	2026-01-01	TEST	f	2026-01-01 18:29:39.276746
11	PO-2175-A1-A1	oyster	PO-2175-A1	2026-03-31	Fra Mycelia order 33092	f	2026-03-31 14:03:22.278087
12	PO2181-LC_2614A	oyster	PO2181-MC-2614A	2026-04-14		t	2026-04-14 10:04:50.473209
13	PO2175-LC-2614A	oyster	PO2175-MC-2614A	2026-04-14		t	2026-04-14 10:05:18.695404
14	HE9514-LC-2614A	lions_mane	HE9514-MC-2614A	2026-04-14		t	2026-04-14 10:05:37.055746
\.


--
-- Data for Name: strain_statistics; Type: TABLE DATA; Schema: public; Owner: mycoflow
--

COPY public.strain_statistics (id, strain_name, lc_code, avg_colonization_days, min_colonization_days, max_colonization_days, avg_yield_kg, total_batches, successful_batches, contamination_rate, avg_be_percent, updated_at, avg_spawn_days, avg_fruiting_days, avg_flush1_days, avg_flush1_kg, avg_flush2_kg, avg_flush2_yield_kg, avg_flushes_per_batch) FROM stdin;
4	reishi	\N	30	24	40	\N	0	0	\N	\N	2025-12-04 14:12:25.895965	\N	\N	\N	\N	\N	\N	\N
3	shiitake	\N	28	21	35	\N	0	0	\N	\N	2025-12-04 14:12:25.895965	28	12	7	\N	\N	\N	\N
2	lions_mane	\N	19	12	28	\N	3	3	\N	\N	2026-01-25 11:04:10.894929	21	10	7	\N	\N	\N	\N
1	oyster	\N	20	9	32	\N	11	11	\N	\N	2026-02-01 09:51:31.515102	14	7	5	\N	\N	\N	\N
\.


--
-- Data for Name: substrate_mixes; Type: TABLE DATA; Schema: public; Owner: mycoflow
--

COPY public.substrate_mixes (id, name, description, moisture_content, is_active, created_at, updated_at, recipe_ingredients, grams_per_bag) FROM stdin;
1	Masters Mix	Standard masters mix (hardwood sawdust + soy hulls)	0.620	t	2026-01-03 16:42:19.822722+01	\N	\N	1650
2	Masters Mix Shiitake	Masters mix optimized for shiitake	0.600	t	2026-01-03 16:42:19.822722+01	\N	\N	1600
3	Halm	Straw-based substrate	0.750	t	2026-01-03 16:42:19.822722+01	\N	\N	1500
4	Sagflis+kli	Sawdust with bran supplement	0.650	t	2026-01-03 16:42:19.822722+01	\N	\N	1650
5	Softwood og kli		0.620	t	2026-01-03 18:34:15.128097+01	\N	[{"name":"Sagflis","grams":"850"},{"name":"Kli","grams":"100"}]	950
7	Lusernemix forsøk 1	Luserne og Østers	0.620	t	2026-01-05 17:02:44.352088+01	\N	[{"name":"Softwood pellets","grams":"450"},{"name":"Luserne","grams":"450"}]	900
6	Lusernemix Forsøk 2	Luserne på LM	0.620	t	2026-01-05 17:01:32.836026+01	2026-03-02 09:05:44.131498+01	[{"name":"Softwood pellets","grams":"540"},{"name":"Luserne","grams":"360"}]	900
8	Lusernemix forsøk 3	Luserne og østers	0.620	t	2026-03-02 09:20:57.612682+01	2026-03-02 09:21:09.72904+01	[{"name":"Softwood pellets","grams":"540"},{"name":"Luserne","grams":"360"}]	900
9	Lusernemix LM forsøk 4		0.620	t	2026-03-31 17:45:40.377445+02	2026-03-31 17:45:54.595846+02	[{"name":"Softwood pellets","grams":"450"},{"name":"Luserne","grams":"360"},{"name":"Soyamel","grams":"45"},{"name":"Gips","grams":"45"},{"name":"Vann","grams":"1350"}]	900
10	Luserne mix forsøk 4 Ø	60/35/5 og 65/30/5	0.620	t	2026-04-11 11:09:22.205025+02	\N	[]	0
\.


--
-- Data for Name: templates; Type: TABLE DATA; Schema: public; Owner: mycoflow
--

COPY public.templates (id, name, strain_name, units_config, created_at, updated_at) FROM stdin;
\.


--
-- Name: batch_info_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mycoflow
--

SELECT pg_catalog.setval('public.batch_info_id_seq', 52, true);


--
-- Name: batch_units_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mycoflow
--

SELECT pg_catalog.setval('public.batch_units_id_seq', 281, true);


--
-- Name: batches_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mycoflow
--

SELECT pg_catalog.setval('public.batches_id_seq', 70, true);


--
-- Name: contamination_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mycoflow
--

SELECT pg_catalog.setval('public.contamination_log_id_seq', 1, false);


--
-- Name: lc_cultures_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mycoflow
--

SELECT pg_catalog.setval('public.lc_cultures_id_seq', 14, true);


--
-- Name: strain_statistics_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mycoflow
--

SELECT pg_catalog.setval('public.strain_statistics_id_seq', 4, true);


--
-- Name: substrate_mixes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mycoflow
--

SELECT pg_catalog.setval('public.substrate_mixes_id_seq', 10, true);


--
-- Name: templates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mycoflow
--

SELECT pg_catalog.setval('public.templates_id_seq', 1, false);


--
-- Name: batch_info batch_info_pkey; Type: CONSTRAINT; Schema: public; Owner: mycoflow
--

ALTER TABLE ONLY public.batch_info
    ADD CONSTRAINT batch_info_pkey PRIMARY KEY (id);


--
-- Name: batch_units batch_units_pkey; Type: CONSTRAINT; Schema: public; Owner: mycoflow
--

ALTER TABLE ONLY public.batch_units
    ADD CONSTRAINT batch_units_pkey PRIMARY KEY (id);


--
-- Name: batches batches_pkey; Type: CONSTRAINT; Schema: public; Owner: mycoflow
--

ALTER TABLE ONLY public.batches
    ADD CONSTRAINT batches_pkey PRIMARY KEY (id);


--
-- Name: batches batches_qr_code_key; Type: CONSTRAINT; Schema: public; Owner: mycoflow
--

ALTER TABLE ONLY public.batches
    ADD CONSTRAINT batches_qr_code_key UNIQUE (qr_code);


--
-- Name: contamination_log contamination_log_pkey; Type: CONSTRAINT; Schema: public; Owner: mycoflow
--

ALTER TABLE ONLY public.contamination_log
    ADD CONSTRAINT contamination_log_pkey PRIMARY KEY (id);


--
-- Name: lc_cultures lc_cultures_lc_code_key; Type: CONSTRAINT; Schema: public; Owner: mycoflow
--

ALTER TABLE ONLY public.lc_cultures
    ADD CONSTRAINT lc_cultures_lc_code_key UNIQUE (lc_code);


--
-- Name: lc_cultures lc_cultures_pkey; Type: CONSTRAINT; Schema: public; Owner: mycoflow
--

ALTER TABLE ONLY public.lc_cultures
    ADD CONSTRAINT lc_cultures_pkey PRIMARY KEY (id);


--
-- Name: strain_statistics strain_statistics_pkey; Type: CONSTRAINT; Schema: public; Owner: mycoflow
--

ALTER TABLE ONLY public.strain_statistics
    ADD CONSTRAINT strain_statistics_pkey PRIMARY KEY (id);


--
-- Name: substrate_mixes substrate_mixes_pkey; Type: CONSTRAINT; Schema: public; Owner: mycoflow
--

ALTER TABLE ONLY public.substrate_mixes
    ADD CONSTRAINT substrate_mixes_pkey PRIMARY KEY (id);


--
-- Name: templates templates_pkey; Type: CONSTRAINT; Schema: public; Owner: mycoflow
--

ALTER TABLE ONLY public.templates
    ADD CONSTRAINT templates_pkey PRIMARY KEY (id);


--
-- Name: idx_batch_units_contamination; Type: INDEX; Schema: public; Owner: mycoflow
--

CREATE INDEX idx_batch_units_contamination ON public.batch_units USING btree (contaminated, contamination_phase) WHERE (contaminated = true);


--
-- Name: idx_batchinfo_fridge; Type: INDEX; Schema: public; Owner: mycoflow
--

CREATE INDEX idx_batchinfo_fridge ON public.batch_info USING btree (in_fridge);


--
-- Name: idx_batchunit_batch_info; Type: INDEX; Schema: public; Owner: mycoflow
--

CREATE INDEX idx_batchunit_batch_info ON public.batch_units USING btree (batch_info_id);


--
-- Name: idx_batchunit_contaminated; Type: INDEX; Schema: public; Owner: mycoflow
--

CREATE INDEX idx_batchunit_contaminated ON public.batch_units USING btree (contaminated);


--
-- Name: idx_contamination_log_date; Type: INDEX; Schema: public; Owner: mycoflow
--

CREATE INDEX idx_contamination_log_date ON public.contamination_log USING btree (contamination_date DESC);


--
-- Name: idx_contamination_log_lc; Type: INDEX; Schema: public; Owner: mycoflow
--

CREATE INDEX idx_contamination_log_lc ON public.contamination_log USING btree (lc_code);


--
-- Name: idx_contamination_log_phase; Type: INDEX; Schema: public; Owner: mycoflow
--

CREATE INDEX idx_contamination_log_phase ON public.contamination_log USING btree (contamination_phase);


--
-- Name: idx_contamination_log_strain; Type: INDEX; Schema: public; Owner: mycoflow
--

CREATE INDEX idx_contamination_log_strain ON public.contamination_log USING btree (strain_name);


--
-- Name: ix_batch_info_id; Type: INDEX; Schema: public; Owner: mycoflow
--

CREATE INDEX ix_batch_info_id ON public.batch_info USING btree (id);


--
-- Name: ix_batch_info_spawn_batch; Type: INDEX; Schema: public; Owner: mycoflow
--

CREATE UNIQUE INDEX ix_batch_info_spawn_batch ON public.batch_info USING btree (spawn_batch);


--
-- Name: ix_batch_units_id; Type: INDEX; Schema: public; Owner: mycoflow
--

CREATE INDEX ix_batch_units_id ON public.batch_units USING btree (id);


--
-- Name: ix_batches_bag_batch; Type: INDEX; Schema: public; Owner: mycoflow
--

CREATE INDEX ix_batches_bag_batch ON public.batches USING btree (bag_batch);


--
-- Name: ix_batches_id; Type: INDEX; Schema: public; Owner: mycoflow
--

CREATE INDEX ix_batches_id ON public.batches USING btree (id);


--
-- Name: ix_batches_lc_batch; Type: INDEX; Schema: public; Owner: mycoflow
--

CREATE INDEX ix_batches_lc_batch ON public.batches USING btree (lc_batch);


--
-- Name: ix_batches_spawn_batch; Type: INDEX; Schema: public; Owner: mycoflow
--

CREATE INDEX ix_batches_spawn_batch ON public.batches USING btree (spawn_batch);


--
-- Name: ix_batches_strain_name; Type: INDEX; Schema: public; Owner: mycoflow
--

CREATE INDEX ix_batches_strain_name ON public.batches USING btree (strain_name);


--
-- Name: ix_substrate_mixes_id; Type: INDEX; Schema: public; Owner: mycoflow
--

CREATE INDEX ix_substrate_mixes_id ON public.substrate_mixes USING btree (id);


--
-- Name: ix_substrate_mixes_name; Type: INDEX; Schema: public; Owner: mycoflow
--

CREATE UNIQUE INDEX ix_substrate_mixes_name ON public.substrate_mixes USING btree (name);


--
-- Name: ix_templates_id; Type: INDEX; Schema: public; Owner: mycoflow
--

CREATE INDEX ix_templates_id ON public.templates USING btree (id);


--
-- Name: batch_units batch_units_batch_info_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mycoflow
--

ALTER TABLE ONLY public.batch_units
    ADD CONSTRAINT batch_units_batch_info_id_fkey FOREIGN KEY (batch_info_id) REFERENCES public.batch_info(id);


--
-- Name: contamination_log contamination_log_batch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mycoflow
--

ALTER TABLE ONLY public.contamination_log
    ADD CONSTRAINT contamination_log_batch_id_fkey FOREIGN KEY (batch_id) REFERENCES public.batches(id) ON DELETE SET NULL;


--
-- Name: contamination_log contamination_log_batch_unit_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mycoflow
--

ALTER TABLE ONLY public.contamination_log
    ADD CONSTRAINT contamination_log_batch_unit_id_fkey FOREIGN KEY (batch_unit_id) REFERENCES public.batch_units(id) ON DELETE SET NULL;


--
-- Name: batches fk_lc_culture; Type: FK CONSTRAINT; Schema: public; Owner: mycoflow
--

ALTER TABLE ONLY public.batches
    ADD CONSTRAINT fk_lc_culture FOREIGN KEY (lc_id) REFERENCES public.lc_cultures(id);


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: mycoflow
--

REVOKE USAGE ON SCHEMA public FROM PUBLIC;


--
-- PostgreSQL database dump complete
--

\unrestrict sgFtlgmNRcYZjM6lJCmCIwLY7iGWTb0K8ijpzsMdkAivcdWx8UjvtqsAVosf4yh

